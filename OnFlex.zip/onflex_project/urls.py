from django.contrib import admin
from django.urls import path
from sistema import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Painel Administrativo (Dono)
    path('admin/', admin.site.urls),

    # Rota Inicial (Dashboard do Técnico)
    path('', views.dashboard, name='dashboard'),

    # Cadastro e Autenticação
    path('registrar/', views.registrar, name='registrar'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Funcionalidades do Dia a Dia
    path('km/registrar/', views.registrar_km, name='registrar_km'),
    path('estoque/', views.estoque, name='estoque'),
    path('relatorios/', views.relatorios, name='relatorios'),

    # NOVA ROTA: Área de Gestão (Acesso restrito ao Dono/Equipe)
    path('gestao/', views.area_gestao, name='area_gestao'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)