from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import ControleKM, Produto, SaidaEstoque
from .forms import RegistrarTecnicoForm # Agora essa importação vai funcionar

def registrar(request):
    if request.method == 'POST':
        form = RegistrarTecnicoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Conta criada! Faça login.')
            return redirect('login')
    else:
        form = RegistrarTecnicoForm()
    return render(request, 'registration/registrar.html', {'form': form})

@login_required
def dashboard(request):
    ultimo = ControleKM.objects.filter(tecnico=request.user).first()
    km_aberto = True if (ultimo and ultimo.km_final is None) else False
    historico = ControleKM.objects.filter(tecnico=request.user)[:5]
    return render(request, 'dashboard.html', {
        'ultimo': ultimo, 
        'km_aberto': km_aberto, 
        'historico': historico
    })

@login_required
def registrar_km(request):
    if request.method == 'POST':
        ultimo = ControleKM.objects.filter(tecnico=request.user).first()
        if ultimo and ultimo.km_final is None:
            km_final = int(request.POST.get('km_final'))
            if km_final < ultimo.km_inicial:
                messages.error(request, "KM Final menor que Inicial!")
            else:
                ultimo.km_final = km_final
                ultimo.save()
                messages.success(request, "Dia finalizado!")
        else:
            km_inicial = int(request.POST.get('km_inicial'))
            novo = ControleKM(tecnico=request.user, km_inicial=km_inicial)
            novo.save()
            if novo.inconsistencia:
                messages.warning(request, novo.mensagem_erro)
            else:
                messages.success(request, "Início registrado!")
    return redirect('dashboard')

@login_required
def estoque(request):
    produtos = Produto.objects.all()
    if request.method == 'POST':
        prod_id = request.POST.get('produto')
        qtd = int(request.POST.get('quantidade'))
        os = request.POST.get('os')
        produto = Produto.objects.get(id=prod_id)
        try:
            SaidaEstoque.objects.create(tecnico=request.user, produto=produto, quantidade=qtd, os_servico=os)
            messages.success(request, "Baixa realizada!")
        except Exception as e:
            messages.error(request, f"Erro: {e}")
    return render(request, 'estoque.html', {'produtos': produtos})

@login_required
def relatorios(request):
    kms = ControleKM.objects.all().order_by('-data')
    saidas = SaidaEstoque.objects.all().order_by('-data')
    return render(request, 'relatorios.html', {'kms': kms, 'saidas': saidas})

import csv
from django.http import HttpResponse
from django.contrib.auth.decorators import user_passes_test
# ... (mantenha as outras importações que já existem: render, redirect, models, forms)

# Função para verificar se é admin/dono
def eh_admin(user):
    return user.is_staff

@login_required
@user_passes_test(eh_admin)
def area_gestao(request):
    # Pega as datas do filtro (se houver)
    data_inicio = request.GET.get('data_inicio')
    data_fim = request.GET.get('data_fim')

    # Busca todos os registros (do mais recente para o antigo)
    kms = ControleKM.objects.all().order_by('-data')
    saidas = SaidaEstoque.objects.all().order_by('-data')

    # Aplica o filtro de data se foi preenchido
    if data_inicio and data_fim:
        kms = kms.filter(data__date__range=[data_inicio, data_fim])
        saidas = saidas.filter(data__date__range=[data_inicio, data_fim])

    # Lógica de Exportação (Download)
    if 'download' in request.GET:
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="relatorio_geral.csv"'

        writer = csv.writer(response)
        writer.writerow(['--- CONTROLE DE KM ---'])
        writer.writerow(['Técnico', 'Data', 'KM Inicial', 'KM Final', 'Status'])
        for k in kms:
            status = "ERRO" if k.inconsistencia else "OK"
            writer.writerow([k.tecnico.username, k.data.strftime("%d/%m/%Y"), k.km_inicial, k.km_final, status])

        writer.writerow([]) # Linha vazia
        writer.writerow(['--- SAÍDA DE ESTOQUE ---'])
        writer.writerow(['Técnico', 'Produto', 'Qtd', 'Data', 'OS'])
        for s in saidas:
            writer.writerow([s.tecnico.username, s.produto.nome, s.quantidade, s.data.strftime("%d/%m/%Y"), s.os_servico])

        return response

    return render(request, 'admin_dashboard.html', {
        'kms': kms, 
        'saidas': saidas,
        'data_inicio': data_inicio,
        'data_fim': data_fim
    })