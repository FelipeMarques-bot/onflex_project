from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils import timezone

class Produto(models.Model):
    nome = models.CharField(max_length=100)
    codigo = models.CharField(max_length=50, unique=True)
    quantidade_estoque = models.IntegerField(default=0)
    # Campo para upload de imagem
    imagem = models.ImageField(upload_to='produtos/', null=True, blank=True)

    def __str__(self):
        return f"{self.nome} (Estoque: {self.quantidade_estoque})"

class ControleKM(models.Model):
    tecnico = models.ForeignKey(User, on_delete=models.CASCADE)
    data = models.DateTimeField(default=timezone.now)
    km_inicial = models.IntegerField()
    km_final = models.IntegerField(null=True, blank=True)
    inconsistencia = models.BooleanField(default=False)
    mensagem_erro = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['-data']

    def save(self, *args, **kwargs):
        # Verifica o último registro para validar a continuidade do KM
        ultimo = ControleKM.objects.filter(tecnico=self.tecnico).exclude(id=self.id).first()
        if ultimo and ultimo.km_final:
            if self.km_inicial != ultimo.km_final:
                self.inconsistencia = True
                self.mensagem_erro = f"ERRO: Iniciou com {self.km_inicial}, mas terminou o anterior com {ultimo.km_final}."
            else:
                self.inconsistencia = False
        super().save(*args, **kwargs)

class SaidaEstoque(models.Model):
    tecnico = models.ForeignKey(User, on_delete=models.CASCADE)
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.IntegerField()
    data = models.DateTimeField(auto_now_add=True)
    os_servico = models.CharField(max_length=50, verbose_name="Ordem de Serviço")

    def save(self, *args, **kwargs):
        if not self.pk:
            if self.produto.quantidade_estoque >= self.quantidade:
                self.produto.quantidade_estoque -= self.quantidade
                self.produto.save()
            else:
                raise ValidationError("Estoque insuficiente!")
        super().save(*args, **kwargs)