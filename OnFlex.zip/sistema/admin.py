from django.contrib import admin
from .models import Produto, ControleKM, SaidaEstoque

@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'codigo', 'quantidade_estoque')
    search_fields = ('nome', 'codigo')

@admin.register(ControleKM)
class ControleKMAdmin(admin.ModelAdmin):
    list_display = ('tecnico', 'data', 'km_inicial', 'km_final', 'inconsistencia')
    list_filter = ('tecnico', 'inconsistencia')

@admin.register(SaidaEstoque)
class SaidaEstoqueAdmin(admin.ModelAdmin):
    list_display = ('tecnico', 'produto', 'quantidade', 'data', 'os_servico')