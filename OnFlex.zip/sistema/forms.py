from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.validators import RegexValidator

class RegistrarTecnicoForm(UserCreationForm):
    # Validação simplificada conforme solicitado: Letras, números e @/./+/-/_
    username = forms.CharField(
        max_length=150,
        required=True,
        validators=[RegexValidator(
            regex=r'^[\w.@+-]+$',
            message='O nome de usuário pode conter apenas letras, números e os caracteres @/./+/-/_.'
        )],
        help_text='Obrigatório. 150 caracteres ou menos. Letras, números e @/./+/-/_ apenas.',
        label="Nome de Usuário"
    )

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']